package myapp.cadastros;

public class Empresa  {
	private Cadastro cadastro;
	private Long im;
	private Long ie;
	
	public Empresa() {
		
	}
    public Empresa(Long im, Long ie) {
		
	}

	
	
	public Cadastro getCadastro() {
		return cadastro;
	}
	public void setCadastro(Cadastro cadastro) {
		this.cadastro = cadastro;
	}
	public Long getIm() {
		return im;
	}
	
	public Long getIe() {
		return ie;
	}
	
	

}
