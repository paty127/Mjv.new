package myapp.metodos;

public class Calculadora {
	//retorno + identificador + parametros ()
	public double somar(int n1, double n2) {
		double r = n1 +n2;
		return r;
	}
	
	
}
