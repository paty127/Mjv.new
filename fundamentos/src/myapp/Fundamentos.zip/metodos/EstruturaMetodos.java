package myapp.metodos;

public class EstruturaMetodos {
	public double somar(int n1, double n2) {
		double r =n1+n2;
		retur r;
	}

}
